/*
CSM 2670 Exercise Set 1

Lucas Lower
01/10/2018

File: HelloWorld.java

Displays "Hello, world!" on the standard output.
Inspired by the first program in Kernighan and Ritchie's
"The C Programming Language"
*/

public class Main {

    public static void main(String[] args) {
        javax.swing.JOptionPane.showMessageDialog(null, "Hello, world!");
    }

}
